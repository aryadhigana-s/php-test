<?php
echo "Hello Word";
?>